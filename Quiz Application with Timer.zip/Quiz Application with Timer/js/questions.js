// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "What tastes better than it smells?",
    answer: "Your tongue",
    options: [
      "Your nose",
      "Your tongue",
      "Your ear",
      "Your lips"
    ]
  },
    {
    numb: 2,
    question: "What building has the most stories?",
    answer: "A library",
    options: [
      "A mall",
      "A hospital",
      "A library",
      "A park"
    ]
  },
    {
    numb: 3,
    question: "What has a bottom at the top?",
    answer: "legs",
    options: [
      "legs",
      "shoulder",
      "feet",
      "head"
    ]
  },
    {
    numb: 4,
    question: "What has four wheels and flies?",
    answer: "A garbage truck",
    options: [
      "A garbage truck",
      "An airplane",
      "A mosquito",
      "A flying fish"
    ]
  },
    {
    numb: 5,
    question: "What month of the year has 28 days in it?",
    answer: "All month",
    options: [
      "February",
      "August",
      "December",
      "All month"
    ]
  },
    {
    numb: 6,
    question: "What can you put in a bucket to make it weigh less?",
    answer: "A hole",
    options: [
      "A water",
      "A hole",
      "A banana",
      "A carrot"
    ]
  },
    {
    numb: 7,
    question: "What starts with T, ends with T, and has T in it?",
    answer: "A teapot",
    options: [
      "A threat",
      "A thruth",
      "A teaspoon",
      "A teapot"
    ]
  },
    {
    numb: 8,
    question: "What has 13 hearts but no other organs?",
    answer: "A deck of cards",
    options: [
      "An octopus",
      "A deck of cards",
      "A gorilla",
      "A women"
    ]
  },
    {
    numb: 9,
    question: "What type of cheese is made backwards?",
    answer: "Edam",
    options: [
      "eden",
      "mozzarella",
      "melt cheese",
      "Edam"
    ]
  },
    {
    numb: 10,
    question: "What kind of ship has two mates but no captain?",
    answer: "A relationship",
    options: [
      "A crew ship",
      "A sportsmanship",
      "A relationship",
      "Cokaliong"
    ]
  },
    {
    numb: 11,
    question: "Who has married many people but has never been married himself?",
    answer: "A priest",
    options: [
      "A priest",
      "A bride",
      "The groom",
      "A wedding coordinator"
    ]
  },
    {
    numb: 12,
    question: "What has three feet but cannot walk?",
    answer: "A yardstick",
    options: [
      "A duck",
      "A tricycle",
      "A yardstick",
      "A seesaw"
    ]
  },
    {
    numb: 13,
    question: "What do you call a nose that's 12 inches long?",
    answer: "A foot",
    options: [
      "A foot",
      "A ruler",
      "A cloud",
      "A shirt"
    ]
  },
    {
    numb: 14,
    question: "What has to be broken before you can use it?",
    answer: "An egg",
    options: [
      "A can",
      "A glass",
      "An egg",
      "Your heart"
    ]
  },
    {
    numb: 15,
    question: "What gets shorter as it grows older?",
    answer: "A candle",
    options: [
      "Your age",
      "A candle",
      "A height",
      "A money"
    ]
  },
    {
    numb: 16,
    question: "What can you catch but never throw?",
    answer: "A cold",
    options: [
      "A Cold",
      "An egg",
      "A stone",
      "An ice"
    ]
  },
    {
    numb: 17,
    question: "What runs around a whole yard without moving?",
    answer: "A fence",
    options: [
      "The owner",
      "A dog",
      "A yard",
      "A fence"
    ]
  },
    {
    numb: 18,
    question: "What five-letter word becomes shorter when you add two letters to it?",
    answer: "Short",
    options: [
      "Color",
      "Short",
      "Longs",
      "Stone"
    ]
  },
    {
    numb: 19,
    question: "What has a face and two hands but no arms or legs?",
    answer: "A clock",
    options: [
      "A human",
      "A chicken",
      "A clock",
      "An egg"
    ]
  },
    {
    numb: 20,
    question: "What has many keys but cannot open a single lock?",
    answer: "A piano",
    options: [
      "A keychain",
      "Un umbrella",
      "A doorknob",
      "A piano"
    ]
  }, 
    {
    numb: 21,
    question: "What's always found on the ground but never gets dirty?",
    answer: "Shadow",
    options: [
      "Person",
      "Water",
      "Shadow",
      "Soap"
    ]
  },   
    {
    numb: 22,
    question: "What gets wet while drying?",
    answer: "A towel",
    options: [
      "A Hanger",
      "A towel",
      "A washingmachine",
      "A blower"
    ]
  },  
    {
    numb: 23,
    question: "What has a head and a tail but no body?",
    answer: "Coin",
    options: [
      "Coin",
      "Seahorse",
      "Shark",
      "Icecream"
    ]
  }, 
    {
    numb: 24,
    question: "What has many teeth but cannot bite?",
    answer: "Comb",
    options: [
      "Shark",
      "Comb",
      "Dog",
      "Badminton"
    ]
  },   
    {
    numb: 25,
    question: "What has one head, one foot, and four legs?",
    answer: "Bed",
    options: [
      "Bed",
      "Table",
      "Chair",
      "Mop"
    ]
  },  
    {
    numb: 26,
    question: "What's always running but never gets hot?",
    answer: "Refrigerator",
    options: [
      "Rice cooker",
      "Stove",
      "Refrigerator",
      "Computer"
    ]
  },  
    {
    numb: 27,
    question: "What can fill a room but takes up no space?",
    answer: "Light",
    options: [
      "Moon",
      "Earth",
      "Keyboard",
      "Light"
    ]
  },  
    {
    numb: 28,
    question: "What do you bury when it's alive and dig up when it's dead?",
    answer: "Plant",
    options: [
      "Animals",
      "Human",
      "Plant",
      "Kids"
    ]
  },  
    {
    numb: 29,
    question: "What common English verb becomes its own past tense by rearranging its letters?",
    answer: "Eat",
    options: [
      "Eat",
      "Plate",
      "jump",
      "climb"
    ]
  }, 
   {
    numb: 30,
    question: "What do you lose the moment you share it?",
    answer: "A secret",
    options: [
      "Answer",
      "Food",
      "A secret",
      "Juice"
    ]
  },

];